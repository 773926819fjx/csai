def filter_sequence(cond, start, stop):
    """
    Returns the sum of numbers from start (inclusive) to stop (inclusive) that satisfy
    the one-argument function cond.

    >>> filter_sequence(lambda x: x % 2 == 0, 0, 10) # .Case 1
    30
    >>> filter_sequence(lambda x: x % 2 == 1, 0, 10) # .Case 2
    25
    """
    "*** YOUR CODE HERE ***"
    sum = 0
    for x in range(start, stop + 1):
        if cond(x):
            sum = sum + x
    return sum


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)
